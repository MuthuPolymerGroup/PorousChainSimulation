Programmed by Zachary E. Dell
Copyright (C) 2018 by Zachary E. Dell
All Rights Reserved


This readme file describe the structure of the code used to generate "PoreSimulation.out" For information about how to execute the simulation, please see "README-Executable"

Purpose: Runs a Langevin dynamics simulation for a polymer chain inside a porous chamber, starting from a chain in a straight line along the chamber axis. This simulation is more fully describe in the paper:

Anomalous packing and dynamics of a polymer chain confined in a static porous envrionment.
ZE Dell and M Muthukumar, J. Chem. Phys. 149, 174902 (2018)

-------------------------------------------------------------------------------

The code is set up in a rather general fashion, to run Langevin dynamics for a single
linear polymer chain. The code is structured using three template classes:

	(i) InitializeChain 
	
	A template for methods that setup the initial positions and velocities of the chain. The constructor for the template requires the number of beads as input. Furthermore there are two class functions, meant to be overloaded in children, which initialize the chain position and velocities:
			
			(a) InitializeChainPos()
			(b) InitializeChainVel()
			
	(ii) SystemModel
	
	A template for the model of the system forces. The constructor for the template requires the thermal_energy, friction, and time_step_size as input. Furthermore,there are three class functions, meant to be overloaded in children
			
			(a) Pair_Force(MyVector, MyVector)
					Determines the pairwise interactions experienced between all beads (LJ for example)
			(b) Bond_Force(MyVector, MyVector)
					Determines the bonding interactions experienced between beads with neighboring indices (FENE for example)
			(c) External_Force(MyVector)
					Determines the external force between a bead and any external fields (gravity, confinement walls, electric field, etc.)
			
	(iii) SimulationMethod
	
	A template for the simulation method used. The constructor requires no inputs and there is one class function, meant to be overloaded in children:
			
			(a)RunSimulation(int, int, string) 
	
-------------------------------------------------------------------------------


Below we provide a brief description of the existing specific classes for each
of the above types. For further info please see the code:

----InitializeChain Classes----------------------------------------
In all cases velocities are initialized with a Maxwell-Boltzmann distribution

	1) InitInLine - initializes the beads on the chain in a straight line along the 
				z axis
				
	2) RandomInit - initialzies the first bead on the chain at the origin and the 
				rest as a random walk
	
	3) SphRandomInit - initialzies the chain as a random walk confined inside a sphere
	

----SystemModel Classes----------------------------------------
	1) KremerGrestModel - Kremer Grest chain (FENE bonds + LJ interactions) 
							with no confinement potential
	
	2) KremerGrestPores - Same as (1) but confined inside the porous chambers
	
	3) KremerGrestSphere - Same as (1) but confined inside a sphere
	
	4) PowerLawSphere - FENE bonds + repulsize power law interactions 
						confined inside a sphere

----SimulationMethod Classes----------------------------------------
In both cases a second order Langevin integrator is implemented

	1) GaussianSimulation - Simulates a chain with no pairwise interactions
							other than the bonding. This is a separate class
							because pairwise interactions slow down the simulation 
							from O(N) to O(N^2).
	
	2) ExcVolSimulation - Simulates a chain with pairwise interactions
	
-------------------------------------------------------------------------------

A makefile is provided for compiling the code. Any added classes would need to be appropriately added to the "Main.h" file and the makefile. The makefile uses g++. To compile the code simply run the command:

make

from the SimulationCode/ directory. Additionally, running:

make clean

will clean all of the object files and clear out the compilation history.






