Programmed by Zachary E. Dell
Copyright (C) 2018 by Zachary E. Dell
All Rights Reserved


This readme file describe the use of the executable "PoreSimulation.out" for information about the code behind this executable, please see "README-Code"

Purpose: Runs a Langevin dynamics simulation for a polymer chain inside a porous chamber, starting from a chain in a straight line along the chamber axis. This simulation is more fully describe in the paper:

Anomalous packing and dynamics of a polymer chain confined in a static porous envrionment.
ZE Dell and M Muthukumar, J. Chem. Phys. 149, 174902 (2018)

-----------------------------------------------------------------------------
To run the simulation, run the following command

./PoreSimulation.out #num_beads #Rsph #Rcyl #Lcyl #num_steps #skip_steps

where all quantities beginning with # should be replaced with the appropriate number. 

Inputs:
		#num_beads - an integer indicating the chain length
		
		#Rsph #Rcyl #Lcyl - floats indicating the geometry of the porous environment
							(R_sph = spherical chamber radius 
							 R_cyl = cylindrical channel radius
							 L_cyl = cylindrical channel length)
							 
		#num_steps #skip_steps - integers denoting the number of time steps to take 
								and number of time steps between outputs (skip_steps).
								The time step size is 0.01*bead diffusion time

Outputs:
		In the directory Outputs/ the simulation will output three types of files:
			
			(i) A .vtf file with the positions of the beads every skip_step time steps
				and the connectivity information of the chain (used for visualization)
			
			(ii) Individual files for positions of the beads every skip_step time steps 
			
			(ii) Individual files for velocities of the beads every skip_step time steps 

--------------------------------------------------------------------------------
The sample outputs have been calculated using:

./PoreSimulation.out 100 2. 1. 1. 10000 1000



