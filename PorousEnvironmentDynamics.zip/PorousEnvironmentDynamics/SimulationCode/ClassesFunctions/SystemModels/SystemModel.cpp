// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//File for client test code

#include "SystemModel.h"		//header file




/*---------------------------------------------------------------------
FUNCTION: Constructor(double thermal_in, double friction_in, double time_step_in))
		purpose: Calculate the pair interaction between 2 particles 
		
		inputs: double thermal_in - thermal energy 
				double friction in - friction constant
				double time_step_in - time step size
--------------------------------------------------------------*/
SystemModel::SystemModel(double thermal_in, double friction_in, 
												double time_step_in) 
{
		// assign the class variables
		thermal_energy = thermal_in;
		friction = friction_in;
		time_step = time_step_in;
}

/*---------------------------------------------------------------------
FUNCTION: Pair_Force(MyVector pos1, MyVector pos2)
		purpose: Calculate the pair interaction between 2 particles 
		
		inputs:  	MyVector pos1 - position of bead 1
					MyVector pos2 - position of bead 2
		
		outputs: 	MyVector - force on bead 1 due to bead 2
				--------------------------------------------------------------*/
MyVector SystemModel::Pair_Force(MyVector pos1, MyVector pos2) 
{
		MyVector out_force(0.,0.,0.);
		
		return out_force;

}

/*---------------------------------------------------------------------
FUNCTION:  Bond_Force(MyVector pos1, MyVector pos2)
		purpose: Calculate the bonding force between 2 particles 
		
		inputs:  	MyVector pos1 - position of bead 1
					MyVector pos2 - position of bead 2
		
		outputs: 	MyVector - force on bead 1 due to bead 2
----------------------------------------------------------------------*/
MyVector SystemModel::Bond_Force(MyVector pos1, MyVector pos2) 
{
		MyVector out_force(0.,0.,0.);
		
		return out_force;
}

/*---------------------------------------------------------------------
FUNCTION: External_Force(MyVector pos1)  
		purpose: Calculate the external force on a particle 
		
		inputs:  	MyVector pos1 - position of bead 1
		
		outputs: 	MyVector - force on bead 1
-----------------------------------------------------------------------*/
MyVector SystemModel::External_Force(MyVector pos1) 
{	
		MyVector out_force(0.,0.,0.);
		
		return out_force;
}





