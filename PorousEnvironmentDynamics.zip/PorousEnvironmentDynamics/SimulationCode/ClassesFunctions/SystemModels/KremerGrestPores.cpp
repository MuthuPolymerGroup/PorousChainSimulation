// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved

#include "KremerGrestPores.h"		//header file

/*---------------------------------------------------------------------
CONSTRUCTOR:
		input: double sph_rad_in = sphere radius 
			   double cyl_rad_in = cylinder radius 
			   double cyl_len_in = cylinder length 
--------------------------------------------------------------*/
KremerGrestPores::KremerGrestPores(double thermal_in, double fric_in, 
		double time_step_in, double min_pos_sq_in, double max_bond_sq_in,
		double bond_stiff_in, double sph_rad_in, double cyl_rad_in,
		double cyl_len_in)
		: SystemModel(thermal_in, fric_in, time_step_in)
{
	// Variables for Kremer Grest Model
	min_pos_sq = min_pos_sq_in;
	max_bond_sq = max_bond_sq_in;
	bond_stiffness = bond_stiff_in;
	
	// Variable for confinement
	sph_radius = sph_rad_in;
	cyl_radius = cyl_rad_in;
	cyl_length = cyl_len_in;
	
	// Calculate the opening angle and z
	theta_open = asin(cyl_radius/sph_radius);
	z_open = sph_radius*pow((1.-(cyl_radius*cyl_radius)/(sph_radius*sph_radius))
								, 0.5);
	dz = 2.*z_open + cyl_length;

}

/*---------------------------------------------------------------------
FUNCTION: Pair_Force(MyVector pos1, MyVector pos2)
		purpose: Calculate the pair interaction between 2 particles 
		
		inputs:  	MyVector pos1 - position of bead 1
					MyVector pos2 - position of bead 2
		
		outputs: 	MyVector - force on bead 1 due to bead 2
--------------------------------------------------------------*/
MyVector KremerGrestPores::Pair_Force(MyVector pos1, MyVector pos2) 
{
		MyVector out_force(0.,0.,0.);
		MyVector rel_pos = pos1 - pos2;
		double sep_sq = rel_pos.Dot(rel_pos);
		
		if(sep_sq >= min_pos_sq)
			{
			return out_force;
			}
		else
			{
			out_force = rel_pos.SMult(24.*(2.*pow(sep_sq,-7.)
													-pow(sep_sq,-4.)));
			return out_force;
			}
}

/*---------------------------------------------------------------------
FUNCTION:  Bond_Force(MyVector pos1, MyVector pos2)
		purpose: Calculate the bonding force between 2 particles 
		
		inputs:  	MyVector pos1 - position of bead 1
					MyVector pos2 - position of bead 2
		
		outputs: 	MyVector - force on bead 1 due to bead 2
----------------------------------------------------------------------*/
MyVector KremerGrestPores::Bond_Force(MyVector pos1, MyVector pos2) 
{
		MyVector out_force(0.,0.,0.);
		MyVector rel_pos = pos1 - pos2;
		double sep_sq = rel_pos.Dot(rel_pos);
		
		out_force = rel_pos.SMult(bond_stiffness/((sep_sq/max_bond_sq)-1.));
		
		return out_force;
}

/*---------------------------------------------------------------------
FUNCTION: External_Force(MyVector pos1)  
		purpose: Calculate the external force on a particle 
		
		inputs:  	MyVector pos1 - position of bead 1
		
		outputs: 	MyVector - force on bead 1
-----------------------------------------------------------------------*/
MyVector KremerGrestPores::External_Force(MyVector pos1) 
{		
		// Declare variables
		MyVector out_force, pos_wall, pos_unit;
		int m_shift;
		double coord_rad, coord_rho, theta;
		
		// Calculate position in unit cell
		m_shift = floor((pos1.z + z_open)/dz);
		MyVector shift_vec(0., 0., m_shift*dz);
		pos_unit = pos1 - shift_vec;
		
		// Calculate the radial coordinates of the particle
		coord_rad = pow((pos_unit.x*pos_unit.x + pos_unit.y*pos_unit.y 
							+ pos_unit.z*pos_unit.z), 0.5);
		coord_rho = pow((pos_unit.x*pos_unit.x + pos_unit.y*pos_unit.y), 0.5);
		
		// First check if in sphere region 
		if (pos_unit.z >= -z_open and pos_unit.z < z_open)
			{
			// check if not close to wall or exactly central
			if (fabs(sph_radius-coord_rad) >= pow(2., 1./6.) 
				or coord_rad <= 1.e-6)
				{
				return out_force;
				}
			
			// Now check that theta is not in the open region 
			theta = atan(coord_rho/pos_unit.z);
			
			if (fabs(theta) >= theta_open)
				{
				// sphere wall 
				pos_wall = pos_unit.SMult(sph_radius/coord_rad);
				}
			else if (coord_rho <= 1.e-6)
				{
				// near opening and on axis -> force = 0
				return out_force;
				}
			else if (theta > 0.)
				{
				// near opening at +z_open and off axis
				pos_wall.x = cyl_radius*pos_unit.x/coord_rho;
				pos_wall.y = cyl_radius*pos_unit.y/coord_rho;
				pos_wall.z = z_open;
				}
			else
				{
				// near opening at -z_open and off axis
				pos_wall.x = cyl_radius*pos_unit.x/coord_rho;
				pos_wall.y = cyl_radius*pos_unit.y/coord_rho;
				pos_wall.z = -1.*z_open;
				}
			}
		
		// Next check in cylinder region
		else if (pos_unit.z >= z_open and pos_unit.z < z_open + cyl_length)
			{
			
			// check if not close to wall or exactly central
			if (fabs(cyl_radius-coord_rho) >= pow(2., 1./6.) 
				or coord_rho <= 1.e-6)
				{
				return out_force;
				}
			
			// set cylinder wall position
			pos_wall.x = cyl_radius*pos_unit.x/coord_rho;
			pos_wall.y = cyl_radius*pos_unit.y/coord_rho;
			pos_wall.z = pos_unit.z;
			}
		
		// if not in either region (should fold back so never here) return F = 0
		else
			{
			return out_force;
			}
		
		// Calculate the force
		out_force = Pair_Force(pos_unit, pos_wall);
		
		return out_force;
}




