// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation

// include guard
#ifndef SYSTEMMODEL_H
#define SYSTEMMODEL_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>
#include <ctime>
#include <cmath>

using namespace std;

// Forward declarations
	// NONE

// Inclusion of used classes
#include "MyVector.h"

//Class declaration --------------------------------------------------
// base class for system models in my simulations
class SystemModel
	{
	
	public:
		double thermal_energy;
		double friction;
		double time_step;
		
		SystemModel(double, double, double);				//constructor
		virtual MyVector Pair_Force(MyVector, MyVector);	// Pairwise force
		virtual MyVector Bond_Force(MyVector, MyVector);	// Bonding force
		virtual MyVector External_Force(MyVector);		// External Forces
	};
//---------------------------------------------------------------------

#endif
