// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//File for client test code

#include "KremerGrestModel.h"		//header file

/*---------------------------------------------------------------------
CONSTRUCTOR:
		sets Kremer Grest parameters
--------------------------------------------------------------*/
KremerGrestModel::KremerGrestModel(double thermal_in, double fric_in, 
		double time_step_in, double min_pos_sq_in, double max_bond_sq_in,
		double bond_stiff_in)
		: SystemModel(thermal_in, fric_in, time_step_in)
{
	// Variables for Kremer Grest Model
	min_pos_sq = min_pos_sq_in;
	max_bond_sq = max_bond_sq_in;
	bond_stiffness = bond_stiff_in;
	
}

/*---------------------------------------------------------------------
FUNCTION: Pair_Force(MyVector pos1, MyVector pos2)
		purpose: Calculate the pair interaction between 2 particles 
		
		inputs:  	MyVector pos1 - position of bead 1
					MyVector pos2 - position of bead 2
		
		outputs: 	MyVector - force on bead 1 due to bead 2
				--------------------------------------------------------------*/
MyVector KremerGrestModel::Pair_Force(MyVector pos1, MyVector pos2) 
{
		MyVector out_force(0.,0.,0.);
		MyVector rel_pos = pos1 - pos2;
		double sep_sq = rel_pos.Dot(rel_pos);
		
		if(sep_sq >= min_pos_sq)
			{
			return out_force;
			}
		else
			{
			out_force = rel_pos.SMult(24.*(2.*pow(sep_sq,-7.)
													-pow(sep_sq,-4.)));
			return out_force;
			}
}

/*---------------------------------------------------------------------
FUNCTION:  Bond_Force(MyVector pos1, MyVector pos2)
		purpose: Calculate the bonding force between 2 particles 
		
		inputs:  	MyVector pos1 - position of bead 1
					MyVector pos2 - position of bead 2
		
		outputs: 	MyVector - force on bead 1 due to bead 2
----------------------------------------------------------------------*/
MyVector KremerGrestModel::Bond_Force(MyVector pos1, MyVector pos2) 
{
		MyVector out_force(0.,0.,0.);
		MyVector rel_pos = pos1 - pos2;
		double sep_sq = rel_pos.Dot(rel_pos);
		
		out_force = rel_pos.SMult(bond_stiffness/((sep_sq/max_bond_sq)-1.));
		
		return out_force;
}

/*---------------------------------------------------------------------
FUNCTION: External_Force(MyVector pos1)  
		purpose: Calculate the external force on a particle 
		
		inputs:  	MyVector pos1 - position of bead 1
		
		outputs: 	MyVector - force on bead 1
-----------------------------------------------------------------------*/
MyVector KremerGrestModel::External_Force(MyVector pos1) 
{	
		MyVector out_force(0.,0.,0.);
		
		return out_force;
}




