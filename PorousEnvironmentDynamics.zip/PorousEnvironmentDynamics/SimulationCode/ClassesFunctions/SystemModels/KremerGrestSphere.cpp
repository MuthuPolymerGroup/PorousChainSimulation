// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved

#include "KremerGrestSphere.h"		//header file

/*---------------------------------------------------------------------
CONSTRUCTOR:
		input: double sph_rad = sphere radius 
--------------------------------------------------------------*/
KremerGrestSphere::KremerGrestSphere(double thermal_in, double fric_in, 
		double time_step_in, double min_pos_sq_in, double max_bond_sq_in,
		double bond_stiff_in, double radius_in)
		: SystemModel(thermal_in, fric_in, time_step_in)
{
	// Variables for Kremer Grest Model
	min_pos_sq = min_pos_sq_in;
	max_bond_sq = max_bond_sq_in;
	bond_stiffness = bond_stiff_in;
	
	// Variable for spherical confinement
	sph_radius = radius_in;

}

/*---------------------------------------------------------------------
FUNCTION: Pair_Force(MyVector pos1, MyVector pos2)
		purpose: Calculate the pair interaction between 2 particles 
		
		inputs:  	MyVector pos1 - position of bead 1
					MyVector pos2 - position of bead 2
		
		outputs: 	MyVector - force on bead 1 due to bead 2
--------------------------------------------------------------*/
MyVector KremerGrestSphere::Pair_Force(MyVector pos1, MyVector pos2) 
{
		MyVector out_force(0.,0.,0.);
		MyVector rel_pos = pos1 - pos2;
		double sep_sq = rel_pos.Dot(rel_pos);
		
		if(sep_sq >= min_pos_sq)
			{
			return out_force;
			}
		else
			{
			out_force = rel_pos.SMult(24.*(2.*pow(sep_sq,-7.)
													-pow(sep_sq,-4.)));
			return out_force;
			}
}

/*---------------------------------------------------------------------
FUNCTION:  Bond_Force(MyVector pos1, MyVector pos2)
		purpose: Calculate the bonding force between 2 particles 
		
		inputs:  	MyVector pos1 - position of bead 1
					MyVector pos2 - position of bead 2
		
		outputs: 	MyVector - force on bead 1 due to bead 2
----------------------------------------------------------------------*/
MyVector KremerGrestSphere::Bond_Force(MyVector pos1, MyVector pos2) 
{
		MyVector out_force(0.,0.,0.);
		MyVector rel_pos = pos1 - pos2;
		double sep_sq = rel_pos.Dot(rel_pos);
		
		out_force = rel_pos.SMult(bond_stiffness/((sep_sq/max_bond_sq)-1.));
		
		return out_force;
}

/*---------------------------------------------------------------------
FUNCTION: External_Force(MyVector pos1)  
		purpose: Calculate the external force on a particle 
		
		inputs:  	MyVector pos1 - position of bead 1
		
		outputs: 	MyVector - force on bead 1
-----------------------------------------------------------------------*/
MyVector KremerGrestSphere::External_Force(MyVector pos1) 
{		
		// Declare variables
		MyVector out_force(0.,0.,0.);
		MyVector pos_wall;
		double radius;
		
		// Calculate the radial coordinate of the particle
		radius = pow((pos1.x*pos1.x + pos1.y*pos1.y + pos1.z*pos1.z), 0.5);
		
		// if at center of the sphere, there is no force 
		if(radius <= 1.e-6)
			{
			return out_force;
			}
		
		// if not at center of the sphere calculate LJ force with wall
		pos_wall = pos1.SMult(sph_radius/radius);
		out_force = Pair_Force(pos1, pos_wall);
		
		return out_force;
}




