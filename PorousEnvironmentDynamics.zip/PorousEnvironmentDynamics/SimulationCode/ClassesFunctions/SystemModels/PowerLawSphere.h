// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation

// include guard
#ifndef POWERLAWSPHERE_H
#define POWERLAWSPHERE_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>
#include <ctime>
#include <cmath>

using namespace std;

// Forward declarations
	//NONE

// Inclusion of used classes
#include "SystemModel.h"
#include "MyVector.h"

//Class declaration --------------------------------------------------
// default parameters are Kremer Grest Chain, otherwise can set 
class PowerLawSphere: public SystemModel
	{
	
	private:
		double min_pos_sq;;
		double max_bond_sq;
		double bond_stiffness;
		double sph_radius;
		double power;
	
	public:
		PowerLawSphere(double, double, double, double, double,
						  double, double, double); //Constructor
		MyVector Pair_Force(MyVector, MyVector);		// Pairwise force (Power)
		MyVector Bond_Force(MyVector, MyVector);		// Bonding force (FENE)
		MyVector External_Force(MyVector);		// External Forces

	};
//---------------------------------------------------------------------

#endif
