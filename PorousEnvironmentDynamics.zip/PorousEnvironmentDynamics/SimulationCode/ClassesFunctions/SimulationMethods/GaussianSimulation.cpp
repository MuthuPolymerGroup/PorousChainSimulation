// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//File for client test code

#include "GaussianSimulation.h"		//header file

/*---------------------------------------------------------------------
Constructor: (num_beads, time_step, system_model)
		
		inputs:	int num_in = number of beads
				int seed_in = seed for random number generator
				double dt_in = time_step (less than 0.01)
				SystemModel sys_in = model for the forces
				InitializeChain chain_in = schemes to initialize the chain
		
-----------------------------------------------------------------------*/
GaussianSimulation::GaussianSimulation(int num_in, int seed_in, double dt_in,
							SystemModel& sys_in, InitializeChain& chain_in)
				:SimulationMethod()
	{
		// Set variables and allocate Memory for Positions, Velocities and Forces
		num_beads = num_in;
		seed = seed_in;
		chain_pos = new MyVector[num_beads];
		chain_vel = new MyVector[num_beads];
		chain_force = new MyVector[num_beads];
		
		// Set system model and time step
		sys_model = &sys_in;
		sys_model->time_step = dt_in;
		
		// Initialize bead pos, vel, force
		chain_pos = chain_in.InitializeChainPos();
		chain_vel = chain_in.InitializeChainVel();
		CalculateReversibleForces();
		
	}

/*---------------------------------------------------------------------
Destructor:
		frees array memory
-----------------------------------------------------------------------*/
GaussianSimulation::~GaussianSimulation()
	{
		// Deallocate Memory for Positions, Velocities and Forces
		delete(chain_pos);
		delete(chain_vel); 
		delete(chain_force); 
	}


/*---------------------------------------------------------------------
Function: CalculateReversibleForces()
		
		Calculates the reversible (potential based) forces for our simulation
		model
		
-----------------------------------------------------------------------*/
void GaussianSimulation::CalculateReversibleForces()
	{	
		// Make vector for force_on_i
		MyVector force_on_i;
		
		// Reinitialize all forces to zero
		for(int ibead = 0; ibead<num_beads; ibead++)
		{
			chain_force[ibead] = chain_force[ibead].SMult(0.);
		}
		
		
		// loop over bead i
		for(int ibead = 0; ibead<num_beads; ibead++)
		{
			// Calculate the external force on bead i 
			chain_force[ibead] = chain_force[ibead]
								+ sys_model->External_Force(chain_pos[ibead]);
			
			
			// Calculate bonding force on i from i+1 
			if (ibead != num_beads-1)
				{
				force_on_i = sys_model->Bond_Force(chain_pos[ibead], 
												chain_pos[ibead+1]);
				
				//add bond forces to beads i and i+1 
				//(Newton's third law for i+1)
				chain_force[ibead] = chain_force[ibead] + force_on_i;
				chain_force[ibead+1] = chain_force[ibead+1] - force_on_i;
				}
			
		}
	
	}

/*---------------------------------------------------------------------
Function: RunSimulation(int num_steps, int skip_steps, string fileroot)
		
		Run a simulation with num_steps time steps and if provided output 
		to file every skip_step 
		
		Update using 2nd order stochastic algorithm in LJ units:
		
		r(t+dt) = r(t) + v(t)*dt + C(t)
		v(t+dt) = v(t) + (f(t+dt) + f(t))*dt/(2)-fric*v(t)*dt
					+ sigma*dt**0.5*rand_xi - fric*C(t)
		
		C(t) = (f(t)-fric*v(t))*dt**2./2 +sigma*dt**3/2*(rand_xi/2+rand_th/2*3**0.5)
		
		where sigma = sqrt(2*thermal*fric)
			  xi, th - independant random gaussian numbers mean = 0 , stdev = 1
		
-----------------------------------------------------------------------*/
void GaussianSimulation::RunSimulation(int num_steps, int skip_steps, string fileroot)
	{	
		// Declare some useful variables for later
		double time;
		MyVector rand_th, rand_xi, second_order;
		
		// Declare some local variables
		double dt = sys_model->time_step;
		double sigma = pow(2.*sys_model->thermal_energy*sys_model->friction,
																		 0.5);
		double fric = sys_model->friction;
		
		// Create random number generator
		double mean = 0.;
		double std_dev = 1.0;
		mt19937 rand_engine(seed);
		normal_distribution<double> rand_dist(mean, std_dev);
		
		// Some useful powers
		double dt_sq = pow(dt, 2.);
		double dt_half = pow(dt, 0.5);
		double dt_3half = pow(dt, 3./2.);
		
		// Output variables
		string header_traj;
		
		SetupFileVTF(fileroot, num_beads, dt);
		header_traj = "# x, y, z where each line is for 1 bead";
		
		for (int i_time = 0; i_time < num_steps; i_time++)
			{
			time = i_time*dt;
			
			if(i_time % skip_steps == 0)
				{
				cout << i_time << " of " << num_steps-1 << endl;
				//PrintChainProp(3);
				
				WriteStepVTF(fileroot, num_beads, chain_pos);
				
				WriteTrajStep(fileroot, header_traj, num_beads, time, 
							chain_pos, chain_vel);
				}
			
			// Loop over beads for current time update
			for (int ibead = 0; ibead < num_beads; ibead++)
				{
				// Step 1 pick the random forces
				rand_xi.x = rand_dist(rand_engine);
				rand_xi.y = rand_dist(rand_engine);
				rand_xi.z = rand_dist(rand_engine);
				
				rand_th.x = rand_dist(rand_engine);
				rand_th.y = rand_dist(rand_engine);
				rand_th.z = rand_dist(rand_engine);
				
				// Step 2 calculate the second order terms C(t)
				second_order = chain_force[ibead].SMult(dt_sq/2.)
							- chain_vel[ibead].SMult(fric*dt_sq/2.)
							+ rand_xi.SMult(sigma*dt_3half/2.)
							+ rand_th.SMult(sigma*dt_3half/(2.*pow(3.,0.5)));
				
				// Step 3 update the positions
				chain_pos[ibead] = chain_pos[ibead] 
							+ chain_vel[ibead].SMult(dt) + second_order;
							
			
				// Step 3 update the current time part of velocity
				chain_vel[ibead] = chain_vel[ibead] 
								+ chain_force[ibead].SMult(dt/2.)
								- chain_vel[ibead].SMult(fric*dt) 
								- second_order.SMult(fric)
								+ rand_xi.SMult(sigma*dt_half);
				}
			
			// Now recalculate the forces
			CalculateReversibleForces();
			
			// Loop over beads to finish velocity update
			for (int ibead = 0; ibead < num_beads; ibead++)
				{
				chain_vel[ibead] = chain_vel[ibead] 
									+ chain_force[ibead].SMult(dt/2.);
				}
			
			}
			
	}



/*---------------------------------------------------------------------
Function: PrintChainProp(int prop_num)
		
		Prints chain property:
			int prop_num:  1 - positions
						   2 - velocities
						   3 - forces
		
		
-----------------------------------------------------------------------*/
void GaussianSimulation::PrintChainProp(int prop_num)
	{	
		MyVector *out_arr;
		
		if(prop_num == 1)
			{out_arr = chain_pos;}
		else if(prop_num == 2)
			{out_arr = chain_vel;}
		else if(prop_num == 3)
			{out_arr = chain_force;}
		else
			{cout << "1 = pos, 2 = vel, 3 = force" << endl;
			return;}
		
		for(int ibead = 0; ibead<num_beads; ibead++)
			{
			cout << out_arr[ibead].OutString();
			}
		
		return;
	}




