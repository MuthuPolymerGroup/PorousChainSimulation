// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//File for client test code

#include  "SimulationMethod.h"		//header file



/*---------------------------------------------------------------------
Function:  SimulationMethod()
		
		template constructor does nothing
		
-----------------------------------------------------------------------*/
 SimulationMethod::SimulationMethod()
	{
		return;
	}
/*---------------------------------------------------------------------
Function: RunSimulation()
		
		Template function for running the simulation.
		
-----------------------------------------------------------------------*/
void SimulationMethod::RunSimulation(int num_steps, int skip_steps, string root)
	{	
		return;
	}



