// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation

// include guard
#ifndef SIMMETHOD_H
#define SIMMETHOD_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>

using namespace std;

// Forward declarations
	// NONE HERE

// Inclusion of used classes
#include "MyVector.h"

//Class declaration --------------------------------------------------   
class SimulationMethod
	{
		
	public:
		int num_beads;
		
		// Functions
		SimulationMethod(); // constructor
		virtual void RunSimulation(int, int, string); // runs simulation
		
	
	};
//---------------------------------------------------------------------

#endif
