// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation

// include guard
#ifndef GAUSSSIMULATION_H
#define GAUSSSIMULATION_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>
#include <ctime>
#include <cmath>
#include <random>

using namespace std;

// Forward declarations
	// NONE HERE

// Inclusion of used classes
#include "MyVector.h"
#include "SystemModel.h"
#include "InitializeChain.h"
#include "SimulationMethod.h"
#include "Output.h"

//Class declaration --------------------------------------------------   
class GaussianSimulation: public SimulationMethod
	{
	
	private:
		int seed;
		MyVector *chain_pos;  // position vector for each bead
		MyVector *chain_vel;  // velocity vector for each bead
		MyVector *chain_force; // force vector for each bead
		SystemModel *sys_model; // Model for the forces in the system
		
	public:
		int num_beads;
		
		// Functions
		GaussianSimulation(int, int, double, SystemModel&, InitializeChain&);
		~GaussianSimulation();
		void CalculateReversibleForces(); // calculates the forces
		void RunSimulation(int, int, string); // runs simulation
		void PrintChainProp(int); // Prints a property of the chain
		
	
	};
//---------------------------------------------------------------------

#endif
