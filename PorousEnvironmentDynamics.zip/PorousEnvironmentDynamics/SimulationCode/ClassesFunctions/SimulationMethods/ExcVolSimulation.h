// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation

// include guard
#ifndef EXCVOLSIMULATION_H
#define EXCVOLSIMULATION_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>
#include <ctime>
#include <cmath>
#include <random>

using namespace std;

// Forward declarations
	// NONE HERE

// Inclusion of used classes
#include "MyVector.h"
#include "SystemModel.h"
#include "SimulationMethod.h"
#include "Output.h"
#include "InitializeChain.h"

//Class declaration --------------------------------------------------   
class ExcVolSimulation: public SimulationMethod
	{
	
	private:
		int seed;
		MyVector *chain_pos;  // position vector for each bead
		MyVector *chain_vel;  // velocity vector for each bead
		MyVector *chain_force; // force vector for each bead
		SystemModel *sys_model; // Model for the forces in the system
		
	public:
		int num_beads;
		
		// Functions
		ExcVolSimulation(int, int, double, SystemModel&, InitializeChain&);
		~ExcVolSimulation();
		void CalculateReversibleForces(); // calculates the forces
		void RunSimulation(int, int, string); // runs simulation
		void PrintChainProp(int); // Prints a property of the chain
		
	
	};
//---------------------------------------------------------------------

#endif
