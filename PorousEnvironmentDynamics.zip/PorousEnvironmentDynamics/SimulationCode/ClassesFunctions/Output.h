// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation
#ifndef OUTPUT_H
#define OUTPUT_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>
#include <ctime>
#include <fstream>

using namespace std;


// Inclusion of used classes
#include "MyVector.h"


// Function declarations
void WriteTrajStep(string, string , int, double, MyVector*, MyVector*);
void SetupFileVTF(string, int, double);
void WriteStepVTF(string, int, MyVector*);

#endif
