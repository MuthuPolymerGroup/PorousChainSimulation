// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved

//Header file for polymer dynamics simulation

// Guard against multiple declarations
#ifndef MYVECTOR_H
#define MYVECTOR_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>
#include <ctime>

using namespace std;

//Class declaration --------------------------------------------------   
class MyVector
	{
	
	public:
		double x;  // x component
		double y;  // y component
		double z; // z component
		
		//Functions
		MyVector(double=0., double=0., double=0.);
		MyVector operator+(const MyVector&); // vector addition
		MyVector operator-(const MyVector&); // vector subtraction
		MyVector SMult(double); // Scalar Multiplication
		double Dot(const MyVector&); // dot product
		string OutString(); // prints vector to screen
	
	};
//---------------------------------------------------------------------

#endif
