// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved


#include "Output.h"		//header file


/*---------------------------------------------------------------------
FUNCTION: WriteTrajStep(string fileroot, string header, int size, 
						double time, double x_array, double v_array)  
		purpose: Write the current pos and vels of beads on chain to a file
		inputs:  	string fileroot - root for file - output file is 
										fileroot + pos-time=x.xxxx.txt
										fileroot + vel-time=x.xxxx.txt
					string header - header string for file
					int size 	- number of rows in file
					double time - time stamp for file
					double x_array	- array of positions
					double v_array	- array of velocities
		outputs: file							-----------------------------------------------------------------------*/
void WriteTrajStep(string fileroot, string header, int size, double time,
					MyVector* x_array, MyVector* v_array)
{	
	// variable for streams
	ofstream pos_out, vel_out;
	stringstream out_str; 
	
	//open files and check to see if properly opened
	out_str << scientific << setprecision(4);
	out_str << fileroot << "pos-time=" << time << ".txt";
	pos_out.open(out_str.str());
	
	if (pos_out.fail()) 
	{
      cout << "Unable to open file for writing." << endl;
      cout << out_str.str() << endl;
      exit(1);
	}
	out_str.str(" ");
	
	out_str << fileroot << "vel-time=" << time << ".txt";
	vel_out.open(out_str.str());
	
	if (vel_out.fail()) 
	{
      cout << "Unable to open file for writing." << endl;
      cout << out_str.str() << endl;
      exit(1);
	}
	out_str.str(" ");
	
	
	pos_out << header << endl;
	vel_out << header << endl;
	
	for (int idx=0; idx<size; idx++)
		{
		pos_out << x_array[idx].OutString();
		vel_out << v_array[idx].OutString();
		}
	
	
	//close output files
	pos_out.close();
	vel_out.close();

}
//----------------------------------------------------------------------



/*---------------------------------------------------------------------
FUNCTION: SetupFileVTF(string fileroot, int num_beads, double dt) 
		purpose: Opens a file and writes the VTF Structure block
		inputs:  	string fileroot - root for file - output file is 
					int num_beads - number of beads
					double dt - time step file							-----------------------------------------------------------------------*/
void SetupFileVTF(string fileroot, int num_beads, double dt)
{	
	// variable for streams
	ofstream vtf_out;
	stringstream out_stream;
	
	//open files and check to see if properly opened
	out_stream << fileroot << "!vtf-trajectory.vtf";
	vtf_out.open(out_stream.str());
	
	if (vtf_out.fail()) 
	{
      cout << "Unable to open file for writing." << endl;
      cout << out_stream.str() << endl;
      exit(1);
	}
	out_stream.str(" ");
	
	// Output the vtf structure block
	// Write a header line
	vtf_out << "# VTF file for a polymer chain with " << num_beads;
	vtf_out << " beads" << endl << endl;
	
	//---------------------- STRUCTURE BLOCK -----------------------------
	vtf_out << "#-------------- STRUCTURE BLOCK ---------------" << endl;
	
	// Define atoms and bonds
	int LJ_size = 1.;
	vtf_out << "atom 0:" << num_beads-1 << " radius " << LJ_size << endl;
	vtf_out << "bond 0::" << num_beads-1 << endl;
	
	// Define unit cell - in my sim I do not inculde a unit cell
	// because I want to see diffusion, for VMD I will just set it 
	// to something
	
	double cell_size = 2.*num_beads*LJ_size;
	vtf_out << "unitcell " << cell_size << " " << cell_size << " ";
	vtf_out << cell_size << endl;
		
	// Setup timestep headers
	vtf_out << endl << "#----------- TIMESTEP BLOCK ";
	vtf_out << "(dt = " << dt << ")---------------\n";
	
	//close output file
	vtf_out.close();

}
//----------------------------------------------------------------------



/*---------------------------------------------------------------------
FUNCTION: SetupFileVTF(string fileroot, int num_beads, double dt) 
		purpose: Opens a file and writes the VTF Structure block
		inputs:  	string fileroot - root for file - output file is 
					int num_beads - number of beads
					chain_pos - chain positions file							-----------------------------------------------------------------------*/
void WriteStepVTF(string fileroot, int num_beads, MyVector* chain_pos)
{	
	// variable for streams
	ofstream vtf_out;
	stringstream out_stream;
	
	//open files and check to see if properly opened
	out_stream << fileroot << "!vtf-trajectory.vtf";
	vtf_out.open(out_stream.str(), ios::app);
	
	if (vtf_out.fail()) 
	{
      cout << "Unable to open file for writing." << endl;
      cout << out_stream.str() << endl;
      exit(1);
	}
	out_stream.str(" ");
	
	// Output the vtf time block
	vtf_out << endl << "timestep indexed" << endl;
	
	for(int idx=0; idx < num_beads; idx++)
		{
		vtf_out << idx << " " << chain_pos[idx].OutString();
		}
	
	//close output file
	vtf_out.close();

}
//----------------------------------------------------------------------


