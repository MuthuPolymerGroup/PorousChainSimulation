// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation

// include guard
#ifndef INITCHAIN_H
#define INITCHAIN_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>

using namespace std;

// Forward declarations
	// NONE HERE

// Inclusion of used classes
#include "MyVector.h"

//Class declaration --------------------------------------------------   
class InitializeChain
	{
		
	public:
		int num_beads;
		
		// Functions
		InitializeChain(int); // constructor
		virtual MyVector* InitializeChainPos(); // initializes chain positions
		virtual MyVector* InitializeChainVel(); // initializes chain velocities
		
	
	};
//---------------------------------------------------------------------

#endif
