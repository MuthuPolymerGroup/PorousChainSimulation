// Programmed by Zachary E. Dell
// Copyright (C) 2018 by Zachary E. Dell
// All Rights Reserved
   
//Class which initializes a chain positions in a line and velocities randomly

#include "SphRandomInit.h"		//header file


/*---------------------------------------------------------------------
Function: SphRandomInit(int num_beads_in, double step_size_in, 
			double bead_size_in, double thermal_energy_in, double seed_in)
		
		Constructor, initializes the number of beads
		
-----------------------------------------------------------------------*/
SphRandomInit::SphRandomInit(int num_beads_in, double step_size_in, 
			double bead_size_in, double thermal_energy_in, double seed_in,
			int max_steps_in, double radius_in)
	:InitializeChain(num_beads_in)
	{
	
	// set class variables
	step_size = step_size_in;
	bead_size = bead_size_in;
	thermal_energy = thermal_energy_in;
	seed = seed_in;
	max_steps = max_steps_in;
	sph_radius = radius_in;
	
	}



/*---------------------------------------------------------------------
Function: InitializeChainPos()
		
		Initialize chain positions to be in a line along the z-axis with
		desired step size, chain is centered at the origin
		
		Inputs: none
		
		Output: array of MyVector objects with positions
-----------------------------------------------------------------------*/
MyVector* SphRandomInit::InitializeChainPos()
	{	
		// Initialize my vector for beads 
		MyVector *out_positions;
		out_positions = new MyVector[num_beads];
		
		// declare overlap variables
		bool is_overlap = false;
		int counter;
		double bead_size_sq = pow(bead_size, 2.);
		MyVector diff_beads;
		double dist_sq;
		
		
		// Set up random number generator
		double pi = 2.*acos(0.);
		double theta, phi, r0;
		mt19937 theta_engine(seed+1);
		mt19937 phi_engine(seed+2);
		uniform_real_distribution<double> theta_dist(0., pi);
		uniform_real_distribution<double> phi_dist(0., 2.*pi);
		
		// Set the initial position of bead 0 randomly in the sphere
		//rather than r dist for 1 value, just rescale theta
		r0 = (sph_radius/pi)*theta_dist(theta_engine);
		theta = theta_dist(theta_engine);
		phi = phi_dist(phi_engine);
		
		out_positions[0].x = r0*sin(theta)*cos(phi);
		out_positions[0].y = r0*sin(theta)*sin(phi);
		out_positions[0].z = r0*cos(theta);
		
		// Loop over positions and set the positions randomly
		for(int ibead = 1; ibead<num_beads; ibead++)
		{	
			// initialize is_overlap anc counter
			is_overlap = true;
			counter = 0;
			
			// loop until no overlap
			while (is_overlap == true and counter <= max_steps)
			{
				
				// increase counter by 1
				counter++;
				
				// take a random step
				theta = theta_dist(theta_engine);
				phi = phi_dist(phi_engine);
				
				out_positions[ibead].x = out_positions[ibead-1].x
									+ step_size*sin(theta)*cos(phi);
				out_positions[ibead].y = out_positions[ibead-1].y
									+ step_size*sin(theta)*sin(phi);
				out_positions[ibead].z = out_positions[ibead-1].z
									+ step_size*cos(theta);
				
				// make sure the new bead is inside the sphere
				dist_sq = out_positions[ibead].Dot(out_positions[ibead]);
				
				if (dist_sq >= sph_radius*sph_radius)
				{
					is_overlap = true;
					continue;
				}
				else
				{
					is_overlap = false;
				}
				
				// loop over already placed beads and ensure there is no overlap
				for(int jbead=0; jbead<ibead; jbead++)
				{
					//calculate dot product 
					diff_beads = out_positions[jbead] - out_positions[ibead];
					dist_sq = diff_beads.Dot(diff_beads);
					
					if(dist_sq <= bead_size_sq)
					{
						is_overlap = true;
						//cout << "overlap: " << ibead << " " << jbead << endl;
						break;
					}
					else
					{
						is_overlap = false;
					}
				}
			
			//end while
			}
			
			// if counter maxed out exit the program with an error message
			if (counter > max_steps)
				{
				cout << "Could not find a valid spot for bead " << ibead;
				cout << " after " << max_steps << " tries."<<endl;
				
				exit(0);
				}
			
			
		// end for
		}
		
		return out_positions;
	}

/*---------------------------------------------------------------------
Function: InitializeChainVel()
		
		Initialize chain velocities according to the Boltzmann distribution
		
		Inputs: none
		
		Output: array of MyVector objects with velocities
-----------------------------------------------------------------------*/
MyVector* SphRandomInit::InitializeChainVel()
	{	
		
		// Initialize my vector for N beads 
		MyVector* out_vels;
		
		out_vels = new MyVector[num_beads];
		
		// Set random number generator (must compile with -std=c++11)
		// variance of Maxwell Boltzmann is dimensionless T so std_dev = sqrt(T)
		double mean = 0.;
		double std_dev = pow(thermal_energy, 0.5);
		mt19937 rand_engine(seed+2);
		normal_distribution<double> rand_dist(mean, std_dev);
		
		// Loop over position vectors and set the position
		for(int ibead = 0; ibead<num_beads; ibead++)
		{
			out_vels[ibead].x = rand_dist(rand_engine);
			out_vels[ibead].y = rand_dist(rand_engine);
			out_vels[ibead].z = rand_dist(rand_engine);
		}
		
		
		return out_vels;
	
	}



