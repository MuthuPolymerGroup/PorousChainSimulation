// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation

// include guard
#ifndef SPHRANDOMINIT_H
#define SPHRANDOMINIT_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>
#include <cmath>
#include <random>

using namespace std;

// Forward declarations
	// NONE HERE

// Inclusion of used classes
#include "MyVector.h"
#include "InitializeChain.h"

//Class declaration --------------------------------------------------   
class SphRandomInit: public InitializeChain
	{
	
	private:
		double step_size;
		double bead_size;
		double thermal_energy;
		double sph_radius;
		double seed;
		int max_steps;
	
	
	public:
		
		// Functions
		SphRandomInit(int, double, double, double, double, int, double);	// constructor
		MyVector* InitializeChainPos(); // initializes chain positions
		MyVector* InitializeChainVel(); // initializes chain velocities
		
	
	};
//---------------------------------------------------------------------

#endif
