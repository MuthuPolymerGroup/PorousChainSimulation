// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Class which initializes a chain positions in a line and velocities randomly

#include "InitInLine.h"		//header file


/*---------------------------------------------------------------------
Function: InitInLine(int num_beads_in, double step_size_in)
		
		Constructor, initializes the number of beads
		
-----------------------------------------------------------------------*/
InitInLine::InitInLine(int num_beads_in, double step_size_in, 
						double thermal_energy_in, double seed_in)
	:InitializeChain(num_beads_in)
	{
	
	step_size = step_size_in;
	thermal_energy = thermal_energy_in;
	seed = seed_in;
	
	}



/*---------------------------------------------------------------------
Function: InitializeChainPos()
		
		Initialize chain positions to be in a line along the z-axis with
		desired step size, chain is centered at the origin
		
		Inputs: none
		
		Output: array of MyVector objects with positions
-----------------------------------------------------------------------*/
MyVector* InitInLine::InitializeChainPos()
	{	
		
		// Initialize my vector for beads 
		MyVector* out_positions;
		out_positions = new MyVector[num_beads];
		
		// Loop over positions and set the positions with a 
		for(int ibead = 0; ibead<num_beads; ibead++)
		{
			out_positions[ibead].x = 0.;
			out_positions[ibead].y = 0.;
			out_positions[ibead].z = (ibead-num_beads/2.)*step_size;
		}
		
		return out_positions;
	}

/*---------------------------------------------------------------------
Function: InitializeChainVel()
		
		Initialize chain velocities according to the Boltzmann distribution
		
		Inputs: none
		
		Output: array of MyVector objects with velocities
-----------------------------------------------------------------------*/
MyVector* InitInLine::InitializeChainVel()
	{	
		
		// Initialize my vector for N beads 
		MyVector* out_vels;
		
		out_vels = new MyVector[num_beads];
		
		// Set random number generator (must compile with -std=c++11)
		// variance of Maxwell Boltzmann is dimensionless T so std_dev = sqrt(T)
		double mean = 0.;
		double std_dev = pow(thermal_energy, 0.5);
		mt19937 rand_engine(seed+1);
		normal_distribution<double> rand_dist(mean, std_dev);
		
		// Loop over position vectors and set the position
		for(int ibead = 0; ibead<num_beads; ibead++)
		{
			out_vels[ibead].x = rand_dist(rand_engine);
			out_vels[ibead].y = rand_dist(rand_engine);
			out_vels[ibead].z = rand_dist(rand_engine);
		}
		
		
		return out_vels;
	
	}



