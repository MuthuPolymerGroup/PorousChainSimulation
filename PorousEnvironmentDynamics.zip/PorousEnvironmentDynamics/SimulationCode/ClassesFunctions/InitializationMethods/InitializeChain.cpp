// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//File for client test code

#include "InitializeChain.h"		//header file



/*---------------------------------------------------------------------
Function: InitializeChain(int num_beads_in)
		
		Constructor, initializes the number of beads
		
-----------------------------------------------------------------------*/
InitializeChain::InitializeChain(int num_beads_in)
	{
		// set class variable
		num_beads = num_beads_in;
	}



/*---------------------------------------------------------------------
Function: InitializeChainPos()
		
		Virtual fuction which initializes the chain positions
		
-----------------------------------------------------------------------*/
MyVector* InitializeChain::InitializeChainPos()
	{	
		
		// Initialize my vector for N beads 
		MyVector* out_positions;
		
		out_positions = new MyVector[num_beads];
		
		return out_positions;
	}

/*---------------------------------------------------------------------
Function: InitializeChainVel()
		
		Initialize the velocities on a chain to Maxwell Boltzmann
		
-----------------------------------------------------------------------*/
MyVector* InitializeChain::InitializeChainVel()
	{	
		
		// Initialize my vector for N beads 
		MyVector* out_vels;
		
		out_vels = new MyVector[num_beads];
		
		return out_vels;
	
	}



