// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation

// include guard
#ifndef RANDOMINIT_H
#define RANDOMINIT_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>
#include <cmath>
#include <random>

using namespace std;

// Forward declarations
	// NONE HERE

// Inclusion of used classes
#include "MyVector.h"
#include "InitializeChain.h"

//Class declaration --------------------------------------------------   
class RandomInit: public InitializeChain
	{
	
	private:
		double step_size;
		double bead_size;
		double thermal_energy;
		double seed;
	
	
	public:
		
		// Functions
		RandomInit(int, double, double, double, double); 		// constructor
		MyVector* InitializeChainPos(); // initializes chain positions
		MyVector* InitializeChainVel(); // initializes chain velocities
		
	
	};
//---------------------------------------------------------------------

#endif
