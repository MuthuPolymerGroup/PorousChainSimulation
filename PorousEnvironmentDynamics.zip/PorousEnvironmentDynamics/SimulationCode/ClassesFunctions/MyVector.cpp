// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//File for client test code

#include "MyVector.h"		//header file

/*---------------------------------------------------------------------
Constructor: (x, y, x)
		
		inputs:	doubles for x y and z components (default = 0)
		
-----------------------------------------------------------------------*/
MyVector::MyVector(double x_in, double y_in, double z_in)
	{
		x = x_in;
		y = y_in;
		z = z_in;
	}

/*---------------------------------------------------------------------
Overload addition:
		Performs vector addition on vector and in2
-----------------------------------------------------------------------*/
MyVector MyVector::operator+(const MyVector& in2)
	{
		return MyVector(x+in2.x, y+in2.y, z+in2.z);
	}

/*---------------------------------------------------------------------
Overload subtraction:
		Performs vector subtraction on vector and in2
-----------------------------------------------------------------------*/
MyVector MyVector::operator-(const MyVector& in2)
	{
		return MyVector(x-in2.x, y-in2.y, z-in2.z);
	}


/*---------------------------------------------------------------------
function: SMult(double in_const)
		Performs scalar multiplication of vector by in_const
-----------------------------------------------------------------------*/
MyVector MyVector::SMult(double in_const)
	{
		return MyVector(x*in_const, y*in_const, z*in_const);
	}


/*---------------------------------------------------------------------
function: Dot(in2)
		Performs dot product of this vector with in2
-----------------------------------------------------------------------*/
double MyVector::Dot(const MyVector& in2)
	{
		return (x*in2.x + y*in2.y + z*in2.z);
	}

/*---------------------------------------------------------------------
function: OutString()
		Returns a string rep of vector
-----------------------------------------------------------------------*/
string MyVector::OutString()
	{	
		stringstream out_stream;
		
		out_stream << scientific << setprecision(5);
		out_stream << x << " " << y << " " << z << endl;
		
		return out_stream.str();
	}


