// Programmed by Zachary E. Dell
// Copyright (C) 2019 by Zachary E. Dell
// All Rights Reserved
   
// Main file for polymer dynamics simulation

#include "Main.h"		//header file


int main(int argc, char* argv[])
	{	
		// Delcare input vars for command line inputs
		int num_beads; // polymer chain length
		double sph_rad, cyl_rad, cyl_len; // geometric parameters
		int num_steps, skip_steps; // simulation length
		
		stringstream(argv[1]) >> num_beads;
		stringstream(argv[2]) >> sph_rad;
		stringstream(argv[3]) >> cyl_rad;
		stringstream(argv[4]) >> cyl_len;
		stringstream(argv[5]) >> num_steps;
		stringstream(argv[6]) >> skip_steps;
		
		
		
//--------Declare and Initialize Variables -----------------------------
		
		// Model variables
		double thermal_energy = 1.0;
		double friction = 0.5;
		double time_step = 0.01;
		
		// Kremer--Grest variables
		double min_pos_sq = pow(2., 1./3.);
		double max_bond_sq = pow(1.5, 2.0);
		double bond_stiffness = 30.;
		
		// Initialization variables
		double init_sep = 1.2;
		double seed = time(NULL);
		
//-------------------------------------------------------------------------
//------------Declare Simulation Classes-----------------------------------
		
		// Declare pointers for initialization, model, and simulation classes
		InitializeChain *init_chain;
		SystemModel *sys_model;
		SimulationMethod *sim_method;
		
		
		// initialize chain with appropriate init class 
		// for pores we initialize in a line
		init_chain = new InitInLine(num_beads, init_sep, thermal_energy, seed);
		
		// initialize system model
		// Here we use Kremer Grest chains imbeded in a porous environment
		// Pores are characterized by spherical chambers connected by cylindrical
		// passages
		sys_model = new KremerGrestPores(thermal_energy, friction, time_step, 
						min_pos_sq, max_bond_sq, bond_stiffness, 
						sph_rad, cyl_rad, cyl_len);
		
		// initialize the simulation method
		// Here we use excluded volume, but Gaussian chain can also be done
		sim_method = new ExcVolSimulation(num_beads, 2.*seed, time_step,
										*sys_model, *init_chain);
		
//-------------------------------------------------------------------------
//------------Run the simulation-----------------------------------
		//output root
		stringstream root_stream;
		root_stream << fixed << setprecision(2);
		root_stream << "./Output/N=" << num_beads<< "-R_sph=" << sph_rad; 
		root_stream << "-R_cyl=" << cyl_rad << "-L_cyl=" << cyl_len << "-"; 
		string fileroot = root_stream.str();
		
		
		// Run simulation
		sim_method->RunSimulation(num_steps, skip_steps, fileroot);
		
	}





