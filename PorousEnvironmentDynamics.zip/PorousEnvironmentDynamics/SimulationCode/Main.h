// Programmed by Zachary E. Dell
// Copyright (C) 2017 by Zachary E. Dell
// All Rights Reserved
   
//Header file for polymer dynamics simulation

// include guard
#ifndef MAIN_H
#define MAIN_H

#include <iomanip>
#include <locale>
#include <sstream>
#include <iostream>
#include <ctime>
#include <cmath>
#include <random>

using namespace std;

// Forward declarations
	// NONE HERE

// Initialization classes
#include "InitializeChain.h"
#include "InitInLine.h"
#include "RandomInit.h"
#include "SphRandomInit.h"

// System Model Classes
#include "SystemModel.h"
#include "KremerGrestModel.h"
#include "KremerGrestPores.h"
#include "KremerGrestSphere.h"
#include "PowerLawSphere.h"

// Simulation classes
#include "SimulationMethod.h"
#include "GaussianSimulation.h"
#include "ExcVolSimulation.h"


// Other classes
#include "MyVector.h"


#endif
